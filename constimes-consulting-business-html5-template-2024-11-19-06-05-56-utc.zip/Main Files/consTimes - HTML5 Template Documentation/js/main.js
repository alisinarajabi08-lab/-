/*
Theme Name: Arfon HTML5 Template
Theme URI: 
Desing by: Suvro
Developed by: Abdullah Al Numan 
Author: Suvro
Version: 1.0
License: 
Tags: 
*/

$(function() {
    "use strict";
    smartScroll.init({
        speed: 900,
        offset: 0,
        activeClass: "active",
    });
});